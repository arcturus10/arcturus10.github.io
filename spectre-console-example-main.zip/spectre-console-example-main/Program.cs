﻿// See https://aka.ms/new-console-template for more information
using System.Diagnostics;
using Spectre.Console;
internal class Program
{
    private static void Main(string[] args)
    {
        Console.Write("Username "); 
        string Username = Console.ReadLine();
        Console.Write("Git");
        var GitProvider = AnsiConsole.Prompt(
            new SelectionPrompt<string>()
            .Title("Select Your Git Provider")
            .PageSize(10)
            .MoreChoicesText("Move up and down to reveal more frameworks")
            .AddChoices(new[] {
            "GitHub [bold][green](Recommended)[/][/]", "GitLab","BitBucket","SourceForge [red]Legacy[/]"
                })) ;
        bool CreateReadme = AnsiConsole.Confirm("Generate a [green]README[/] file?");
        bool CreateGitIgnore = AnsiConsole.Confirm("Generate a [yellow].gitignore[/]");
        AnsiConsole.MarkupLine($"Hi {Username}, Your Git Provider is now >{GitProvider}. To Change Defaults go to Develper Options");
        AnsiConsole.MarkupLine($"Repository spectre.console created for user {Username} in your {GitProvider} Account.");
    }
}